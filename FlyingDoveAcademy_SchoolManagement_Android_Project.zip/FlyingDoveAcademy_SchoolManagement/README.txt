FLYING DOVE ACADEMY SCHOOL MANAGEMENT SYSTEM
Android project / offline-first Android WebView prototype.

Includes:
- Learner registration: Baby Class, Middle Class, Grade 1 to Grade 7
- Learner and teacher/staff attendance
- Test and examination marks with class analysis
- Learner fee/payment ledger, balances and receipt references
- Attendance, payments and examination summaries

Demo login: saeli / 1234

PHONE-ONLY BUILD USING GITHUB ACTIONS:
1. Create a GitHub repository.
2. Upload this entire ZIP file to the repository root (do not extract it).
3. In GitHub, create a new file named .github/workflows/build-apk.yml.
4. Copy the workflow code from this project's .github/workflows/build-apk.yml into that new file and commit it.
5. Open Actions > Build Flying Dove Academy APK > Run workflow.
6. Download the Flying-Dove-Academy-APK artifact and extract app-debug.apk.

LIMITATIONS:
This is an offline prototype. Data is stored locally in the app WebView and is not synchronized between devices. It does not yet provide secure staff accounts, role permissions, cloud backups, online HOD approvals, encrypted database, or financial audit logs. Do not use demo login for confidential learner data. Production deployment requires security review, backups, privacy controls and testing.
